const products = [
  { id: 1, name: "Boneka Kelinci 🐰", price: 55000, image: "https://i.pinimg.com/564x/8b/87/8d/8b878dd8e672c99813b0e0992e59b69b.jpg" },
  { id: 2, name: "Gantungan Cupcake 🧁", price: 25000, image: "https://i.pinimg.com/564x/16/5b/91/165b91384cb004d520ccbc8a7f3f0d20.jpg" },
  { id: 3, name: "Bantal Kucing Lucu 🐱", price: 65000, image: "https://i.pinimg.com/564x/9e/52/b1/9e52b1cfb43a6616922369d3ee42a687.jpg" },
  { id: 4, name: "Tempat Pensil Kawaii 🎀", price: 30000, image: "https://i.pinimg.com/564x/03/f4/61/03f4613aa31971ff41ab4dd217e9e1c1.jpg" },
  { id: 5, name: "Tas Mini Bear 🐻", price: 85000, image: "https://i.pinimg.com/564x/f5/29/35/f529352e340a045e20b6b189836ecb21.jpg" },
  { id: 6, name: "Gelas Lucu 🍓", price: 45000, image: "https://i.pinimg.com/564x/94/2c/79/942c791733d3e9a96a724eb89e25ff2a.jpg" }
];

const container = document.querySelector(".product-list");

container.innerHTML = products.map(item => `
  <div class="product">
    <img src="${item.image}" alt="${item.name}">
    <h3>${item.name}</h3>
    <p>Rp ${item.price.toLocaleString()}</p>
    <button onclick="addToCart(${item.id})">💖 Tambah ke Keranjang</button>
  </div>
`).join('');

function addToCart(id) {
  const item = products.find(p => p.id === id);
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  cart.push(item);
  localStorage.setItem('cart', JSON.stringify(cart));
  alert(`✨ ${item.name} sudah masuk ke keranjang! ✨`);
}